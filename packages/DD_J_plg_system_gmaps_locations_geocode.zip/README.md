# DD_J_plg_system_gmaps_locations
A Joomla! system plugin for DD Google Maps Locations to GeoCode addresses on Extension after save event.

### Dependent Extensions
- mod_gmaps_module [GMaps Module](https://github.com/hr-it-solutions/DD_J_mod_gmaps_module)
